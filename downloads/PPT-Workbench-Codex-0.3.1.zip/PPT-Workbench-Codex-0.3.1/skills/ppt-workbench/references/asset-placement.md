# 素材与布图：按表达用途组织

用于用户要求整理图片、补图、调整图文比例或美术升级。先读当前页与模板，确定图片在说明什么，再选素材。不是每页都要头像、半身图和封面；文字初稿保留用户要求的简洁占位即可。

## 素材角色

| role | 用途 | 主要检查 |
|---|---|---|
| identity | 头像、人物身份 | 人物对应正确，小尺寸仍可辨认 |
| evidence | 真实过往作品、截图 | 来源真实，不用生成图冒充；必要文字不裁掉 |
| concept | 本次提案创意、场景或封面 | 图中动作和结果确实表达本页创意 |
| brand | 官方 Logo、KV、产品资产 | 产品/IP/版本正确，符合指定模板和完整比例 |
| decoration | 氛围与装饰 | 不挤占机制说明，不遮挡有效内容 |

参考图片还需区分内容、版式、美术、品牌系统、人物结构、场景和不可变资产。生成时决定是传入参考像素、仅观察风格，还是仅提取信息；不能将所有上传图无差别传给生成模型。可编辑 PPT 的素材默认少字/无字，常改标题使用原生文本；保留用户已确认的图片封面和真实截图。图中已烘焙的字不能谎称可单独编辑。

只改已有图时固定正确区域，说明变化部分；不重新生成已经满意的主体。图像生成、官网资产下载和达人检索使用目标环境已授权的工具，不硬编码旧项目客户、角色或账号。

## 两份关联记录

`ppt_asset({file})` 返回本地文件 hash/bytes，**不看图**。实际观察后记录来源、身份、用途、透明主体边界或裁切意图。需要视觉判断时必须看原图；历史摘要不能代替这一次的细节判断。

`ppt_placement_plan({targetPath})` 读取当前版本和计划。targetPath 为 deck manifest 或 ppt-workbench-native.json。写入时传 expectedSourceHash 和完整 plan；数组整体替换，先读旧记录。schema 核心如下：

```json
{
  "assets": [{
    "id":"creator-avatar", "file":"C:/项目/assets/avatar.jpg",
    "expectedHash":"从 ppt_asset 获取", "role":"identity", "origin":"creator-work",
    "source":"实际作品或资料来源", "purpose":"识别本页达人",
    "entity":"达人名称", "reviewSummary":"实际查看后的结论", "textBaked":false
  }],
  "placements": [{
    "slideId":"271", "assetId":"creator-avatar", "purpose":"身份区头像",
    "fit":"contain", "group":"creator-identity", "focalPoint":"保留完整头部",
    "allowBleed":false, "preserve":"保留已确认姓名与数据"
  }]
}
```

native slideId 来自 PPTX 当前版本，deck slideId 来自 manifest。origin 可为 user/official/creator-work/generated/other。可补 frame（unit 为 px/emu/cm，含 x/y/width/height）和 layer。approved 只有用户真实确认才写 true。

工具验证文件指纹、页面引用、框尺寸、计划版本，并保留旧计划；它不执行插图、不分析人脸、不判断图好不好。素材文件依旧保存在给定路径，跨机器迁移时连同素材和项目一起带走，并更新路径/指纹记录。

## 从图文关系到布局

- 单达人页：身份信息小、创意或证据图大，机制紧邻其对应图片。
- 多达人对比：每位达人形成头像/标题/图/理由的完整单元，再对齐这些单元；不是把所有图片独立均分。
- 多人联动：小头像负责身份，透明人物负责表现，大封面负责创意，可按需要叠放和出血。
- 证据页：真实作品和本次提案示意分区，让读者知道哪些已经发生、哪些准备做。

这些是可选组合，不是固定模板。美术升级先保留已确认的素材选择、组合和文案，再调整面积、层次、背景和字阶。根据实际可见人物边界缩放透明图，不只按 PNG 画布宽高。照片可 cover，Logo/截图常用 contain；允许用户指定的裁切和重叠。

原生路线使用 prepare 的 work 文件插图/移动对象，再 review；deck 路线快照后修改 HTML，再 check/export。首个代表页验证比例和风格后再扩展，不一口气复制到全稿。

程序检查可覆盖缺图、哈希变化、无效框、部分拉伸与边界风险。低分辨率按实际显示面积判断，不强制所有头像≥1200px；重复图片可能合理；有意出血不等于错误。脸被裁掉、语义不符、主体清晰度和可读性需要实际看图。先联系表看节奏，再看相关单页/素材细节。

交付前消除幕后指令和草稿残留，但保留用户明确需要的占位、真实来源、模板字段。纯净交付不能成为擅自删减已确认机制的理由。

## 全部图位、取材进度与版本

补多页图片时，先把本轮全部需求写入 plan.slots，即使尚无素材也要登记；assets/placements 可以为空。每个图位的 id 稳定，slideId 使用真实页面 ID。小范围只改一个头像无需建立全稿清单。范围改变时明确增减图位及原因，避免把已找到的 3 张图片当成全部需求。

slots 示例：

```json
[{"id":"creator-work-1","slideId":"271","outputKind":"work-evidence","intent":"证明达人擅长漫展路人互动；保留作品标题","status":"needed"}]
```

outputKind：identity 身份图、work-evidence 真实作品、concept-cover 本次创意封面、scene-mockup 场景示意、brand 品牌资产、decoration 装饰。选图前写清人物/主体、动作、场景、要表现的结果，按表达目的填写 intent；不要把真实过往封面直接当成本次创意示意。

status：needed 待取材、blocked 受阻（需 blocker）、acquired 已落盘（需 assetId）、placed 已布图、shown 已提供可用预览、approved 用户确认、rejected 用户否决。后三类确认均是调用方记录，不是工具自动认证。placed 及后续状态需对应 placement、当前 versionHash、matchReview；shown 及后续需 deliveryEvidence；approved/rejected 另需真实 userFeedback。工具无法验证用户是否真的看过，禁止把打开预览的 queued 回执写成已展示。

先保存新 PPT 版本，再基于新 sourceHash 更新图位状态。progress 单独计入 stale，换稿或素材字节变化的旧确认不会计入当前完成数；旧记录保留供核对，不能自动升级为新稿批准。旧计划无 slots 时总数返回 null，不猜完成率。每次写入完整 plan 前先读取原计划，保留有效图位和取材尝试。

attempts 可记录 route、outcome（success/failed/timeout/unavailable）、detail、实际 elapsedMs。失败一次后根据原因切换可用路径，避免新聊天重走同一失败。参考 [达人取材](creator-acquisition.md)。

交付单页时说明本轮修改页、已提供的预览、尚未解决的图位；用户要求逐页确认时，先交付当前页再继续下一页。已放入不等于已验收，已导出不等于已打开。默认保留原图、裁切副本和来源记录；不把收集成功率当成创意匹配率。
