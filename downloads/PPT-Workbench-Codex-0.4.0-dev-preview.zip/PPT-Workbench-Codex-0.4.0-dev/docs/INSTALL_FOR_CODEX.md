# 给目标电脑 Codex 的安装指引

本指引用于用户已经要求下载、安装或迁移本工具的场景。仅查看仓库不构成安装请求。

预览版说明：本版用于真实客户验收，未标为稳定完成。获取codex/workflow-preview-20261102分支；首次登录与本人授权按[ONBOARDING_FOR_CODEX.md](ONBOARDING_FOR_CODEX.md)引导，技术操作由Codex执行，不把命令交给客户。

## 1. 下载并确认环境

目标为 Windows x64 的本机 Codex。检查操作系统、用户目录、CODEX_HOME、网络和可用磁盘空间。使用当前用户权限，不需要管理员。首次安装会下载 Node（若缺失）、npm 包和 Chromium，需要能够访问相应下载服务，预留约 1 GB 以上空间更合适。

从 `https://github.com/vkai4323-byte/PPT-work-TOOLs.git` 克隆codex/workflow-preview-20261102分支到明确的新目录。已有同名目录时先确认其内容，不要清空或覆盖用户工作。没有Git可下载对应分支ZIP或downloads下的独立预览安装包，完整解压。不要只下载SKILL.md或在未保存到本地前直接执行远程脚本。

核对 README、install.ps1 和本指引。独立安装包旁提供 `.sha256` 文件，包内提供 FILES.sha256.json；它们用于发现传输损坏和核对文件一致性，并非独立可信的数字签名。

## 2. 执行完整安装

在仓库或独立安装包根目录运行：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1
```

脚本固定运行依赖，先测试 Chromium、中文字体、可编辑 PPTX 导出与重叠阻断，再注册用户级 MCP、Skill 和全局路由。最后启动两个新的 MCP 连接进行新项目导出验收。保留命令退出码和实际结果，不能只看到“文件已复制”就宣称安装成功。

默认配置写入当前 CODEX_HOME（未设置时为用户 .codex），技能写入用户 .agents/skills/ppt-workbench。原有配置在修改前备份。若目标 Codex 使用自定义配置位置，应使用 `-CodexProfile` 指定实际位置。已有同名、非本安装器管理的 MCP 或 Skill 冲突时检查具体配置，不删除用户内容来绕过检查。

系统缺少全局 node 时，安装器使用独立 Node。后续 CLI 请用安装后的技能 scripts/run.ps1，或读取 runtime.json 的 node 绝对路径，不必另外安装 Node 到 PATH。

## 3. 验证并启用

默认安装后执行：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\verify.ps1
```

自定义运行时目录时补充 `-InstallRoot <目录>`。`-RuntimeOnly` 只用于明确要求不注册 Codex 的运行时安装，它不满足“在所有新项目中可用”的完整安装要求；verify.ps1 包含注册检查，因此不适合只验证 RuntimeOnly。

告诉用户：完全退出再打开 Codex，在新聊天中输入 `$ppt-workbench 先检查环境，再帮我制作 PPT`。若新工具尚未加载，当前聊天可通过安装后的脚本做 CLI 自检，但不能承诺不用重启就能发现新的 MCP。

全局配置让用户以后在其他项目中也能发现能力。项目级规则、企业设置、被禁用的 MCP/Skill 或模型工具选择仍可能影响自动使用；显式 `$ppt-workbench` 更明确。

## 4. 必须向用户解释的内容

0.4.0-dev 的PPT MCP应发现25个工具，取材入口另由workbench-creators技能调用Python脚本。安装自检验证稳定元素修改、快照恢复、原生PPTX接管与项目接续。OfficeCLI现由install-workflow.ps1自动部署固定版本，实际路径在workflow-tools.json；使用verify-workflow.ps1复验，不要求客户配PATH。MCP可发现、OfficeCLI可执行与真实副本编辑验收分别记录。开发进度见WORKFLOW-INTEGRATION.md，不能引用尚不存在的版本说明。

- `$ppt-workbench` 是聊天中的技能调用入口，不是终端命令。
- 它用 HTML 源文件制作 PPT，通过 Chromium 实测排版，并导出可编辑 PPTX。
- 每轮优先文字诊断；预览图片保存在本地、按需查看，减少反复向模型输入截图。
- 它不清理旧会话图片历史，不改变模型/网关限制，也不保证所有任务永不超限。
- 新聊天继续旧稿，应提供 super-adc-deck.json 路径，并读取 progress.md 与 notes。
- 用户手改过的最新 PPTX 应走原文件编辑路线；本包不能无损反向同步回 HTML。
- 尚未执行的目标机 PowerPoint/WPS 视觉验收，应如实列出。

给出 docs/USAGE.md 的“新建”和“继续修改”示例，说明安装路径、验证结果和任何尚未完成项。

## 完整迁移的业务验收

用户要求整套工作流迁移时，安装和verify通过后继续读取[CUSTOMER_ACCEPTANCE.md](CUSTOMER_ACCEPTANCE.md)，执行两页燕云中腰部达人与6张16:9付费创意封面的实际验收。先由Codex复用并核验客户本机已有Monet官方模块；不重新安装无关服务，不复制其他设备凭据。尚缺私有适配登记或接口实现时，由Codex检查本机已成功模块和正式文档后补齐，不能将其说成客户需要重新登录。

付费前向客户集中确认6张图的费用范围及重做条件；发布者不预设积分上限，也没有替客户批准无限支出。保存授权与任务检查点，未知提交不重发。技术问题由Codex处理，只有必要的本人登录、扫码、扩展权限与付费确认交给客户。真实业务验收未通过时，不将安装自检报告为完整迁移成功。

## 故障处理

| 现象 | 处理 |
| --- | --- |
| 下载失败 | 记录失败域名和步骤，检查网络/代理后重试；不要关掉系统安全设置 |
| 找不到微软雅黑 | 安装目标字体或明确配置字体后再验收，不将静默换字体当成成功 |
| 工具未出现 | 核对实际 CODEX_HOME、安装结果及是否重启；先用备用 CLI 验证 |
| 同名配置冲突 | 查看冲突配置和安装备份，保留用户设置，解决后再注册 |
| 原聊天因图片数量失败 | 从已保存的项目文件在新聊天继续，不反复重试同一请求 |

更新时获取新版源码，退出正在使用该运行时的 Codex 后重新运行安装器；不要仅 git pull 后假定已安装运行时同步更新。停用用 uninstall.ps1，它保留运行时和用户 PPT 项目。
