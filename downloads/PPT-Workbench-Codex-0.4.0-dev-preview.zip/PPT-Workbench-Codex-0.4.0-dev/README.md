# PPT Workbench 0.4.0-dev

把本机 SuperADC 的 HTML deck 测量与原生 PPTX 导出能力接到其他 Windows 电脑上的 Codex。安装包包含实际执行引擎、MCP 工具、用户级 Skill 和安装器；不是只加一段“少看图片”的提示词。

0.4.0-dev 为完整工作流预览版，新增星图/B站取材、真实主页截图与按需裁切、固定依赖自动安装、浏览器首次授权引导，以及Monet私有模块登记和生图台账。详见[预览版状态](docs/VERSION-0.4.0-dev.md)。客户机业务验收仍待执行，不能将本版称为完整迁移已通过。

**2026-11-03封面修正：** 客户已回传两页实机截图，发现标题后贴和人物参考未落实的问题。新增[客户封面修正指引](docs/CUSTOMER_COVER_REPAIR.md)：封面花字默认一体生成，要求采用的人物必须实际传图。当前公开文生图入口不能传参考，已阻断把此类任务冒充文生图完成；参考上传/编辑仍须客户Codex按正式接口落实并验证。安装更新前先保留本机已改造的私有模块与当前工作稿。

**先直观看看这次更新：** [下载客户介绍 HTML](https://github.com/vkai4323-byte/PPT-work-TOOLs/raw/refs/heads/codex/workflow-preview-20261102/docs/workbench-update-guide.html)，保存后用浏览器打开。包含可点击流程、6个使用场景、一键复制话术，以及预览版与正式验收的说明；单文件可离线阅读。

0.3.0 补齐原生 PPTX 接管、按批注范围修改、OfficeCLI 批处理、差异检查与版本交付，并加入两条路线共用的素材布图计划。保留 0.2 的 deck 快照与稳定元素能力。制作方式可交叉、跳过或回退，不固定四阶段。详见 [新版说明](docs/VERSION-0.3.md)。

**给不懂技术的使用者：** 下载 [新手教学 HTML](https://github.com/vkai4323-byte/PPT-work-TOOLs/raw/refs/heads/main/docs/beginner-guide.html) 后，用浏览器打开。按7种工作情况查看能做什么、如何提要求、Agent 会怎样操作；支持复制话术，可离线阅读。安装包内也有 `docs/beginner-guide.html`。

新建与已有 PPTX 共用 [设计规则](skills/ppt-workbench/references/design-workflow.md)：明确视觉重点、字阶、色块、主辅比例、留白与页面节奏。默认建议服从客户模板和用户要求，不把所有页面强制改成大字或三卡片。

## 直接交给另一台电脑上的 Codex

复制下面这段话即可：

```text
请从 https://github.com/vkai4323-byte/PPT-work-TOOLs/tree/codex/workflow-preview-20261102 下载并安装 PPT Workbench 完整工作流预览版，请使用该分支。
先阅读仓库 README.md、AGENTS.md 和 docs/INSTALL_FOR_CODEX.md，检查本机环境，
在 Windows 上执行 install.ps1，完成用户级 Skill 与 MCP 注册并运行验证。
保留我原来的 Codex 模型、账号和其他工具配置，不要只复制 SKILL.md。
安装验证后，继续按 docs/CUSTOMER_ACCEPTANCE.md 完成两页燕云十六声中腰部达人PPT验收，
包括抖音/星图和B站各至少3位、真实素材，以及共6张16:9新增创意封面与标题。
生图前向我集中确认费用范围和重做条件；技术问题请自行排查修复，
仅在必要的本人登录、扫码、扩展授权或付费确认时提示我。
如果需要重启 Codex，请明确告诉我；不要把 MCP 自检成功说成 UI 已完成验收。
```

安装方式：克隆指定预览分支后运行根目录 `install.ps1`；没有 Git 时下载[预览分支ZIP](https://github.com/vkai4323-byte/PPT-work-TOOLs/archive/refs/heads/codex/workflow-preview-20261102.zip)，或下载[独立预览安装包](downloads/PPT-Workbench-Codex-0.4.0-dev-preview.zip?raw=1)。代码仓库和独立安装包均包含安装器和必要工作流源码，首次安装自动从官方源获取固定依赖；无需客户分别配置工具。

```powershell
git clone --branch codex/workflow-preview-20261102 https://github.com/vkai4323-byte/PPT-work-TOOLs.git
cd PPT-work-TOOLs
powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1
```

给自动安装的 Codex 的详细步骤见 [INSTALL_FOR_CODEX.md](docs/INSTALL_FOR_CODEX.md)，日常用法见 [使用指南](docs/USAGE.md)。本版安装器面向 Windows x64；不应在 macOS、Linux 或 WSL 上照抄执行。

## `$ppt-workbench` 是什么

它是 Codex 的技能入口：在聊天中写 `$ppt-workbench`，让 Codex 按这套工作流程调用已经安装的本地工具。它不是 PowerShell 命令，也不是单独的模型。

| 能力 | 实际作用 |
| --- | --- |
| 从文案制作 PPT | 建立页序和逐页 HTML 源文件，组织标题、正文、卡片、表格等 |
| 实测排版 | Chromium 测量文字与元素位置，输出溢出、重叠、字体/图片问题的文字诊断 |
| 可编辑导出 | 输出原生文本框、形状、表格及图片，保存为新的 PPTX 版本 |
| 局部改稿 | 通过源文件和对象位置修改指定页；未变化页面复用测量 |
| 按需预览 | 把预览图与联系表保存到本地，工具返回路径，按需开展视觉验收 |
| 跨聊天继续 | 通过项目源文件、notes 和 progress.md 接续工作 |

支持新建 HTML deck，以及已有/用户手改 PPTX 的接管与精修。原生 PPTX 的读取、快照、范围计划和差异检查已内置；OfficeCLI由安装器自动获取。星图/B站适配器、截图与裁切入口随包提供；浏览器扩展及平台本人授权在客户机完成，生图复用客户已有的官方私有Monet模块和凭据。

## 在另一台电脑安装

1. 将 ZIP 复制到目标电脑，完整解压。
2. 双击 `install.cmd`，或在解压目录打开 PowerShell，执行：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1
```

3. 安装成功后完全退出并重新打开 Codex，新建聊天，第一次使用可输入：

```text
$ppt-workbench 请先检查 PPT 环境，然后根据我的文案制作可编辑 PPT。
将项目保存到当前工作目录下的新文件夹，先确定页序，再制作、检查并导出。
```

以后新项目、新聊天可直接说“帮我制作 PPT”；全局规则会优先路由到此技能。项目规则、显式工具要求、企业配置或禁用 MCP 等设置仍可能影响路由。若没有自动选中，显式调用 `$ppt-workbench`。不能把用户级安装理解为模型每次一定作出相同选择。

系统要求：Windows x64、可写的用户目录，安装时能够访问 npm、Playwright 下载服务；缺少 Node 时还需要访问 nodejs.org。无需管理员权限，无需安装 SuperADC。已有 Node >=22.12 时复用；否则下载并校验 Node 24.14.0。Chromium 和 JS 依赖版本固定在 package-lock.json。默认使用系统微软雅黑，字体缺失会报错而非静默换字体。生成 PPTX 不要求安装 Office；要验证实际 PowerPoint 排版，需要 PowerPoint。

## 安装到哪里

- 运行时：`%LOCALAPPDATA%\PPTWorkbench\0.4.0-dev`。
- 浏览器：`%LOCALAPPDATA%\PPTWorkbench\browsers`。
- Skill：`%USERPROFILE%\.agents\skills\ppt-workbench`。
- 工具注册：`%CODEX_HOME%\config.toml`；未设置 CODEX_HOME 时为 `%USERPROFILE%\.codex\config.toml`。
- 全局路由：同一 Codex 配置目录中的 AGENTS.md；若已有非空 AGENTS.override.md，则写入实际生效的 override。

保留原有配置并备份到 `ppt-workbench-backups`。遇到非本安装器管理的同名 MCP/Skill 时停止，避免覆盖。安装前先运行真实导出与错误阻断验收，失败时不注册 Codex 配置。用户原有 API、模型、账号和其他工具设置不随包迁移。

可选参数：`-InstallRoot` 改运行时目录，`-UserHome`/`-CodexProfile` 指定其他配置位置，`-BrowserCache` 复用明确的浏览器缓存，`-RuntimeOnly` 只安装运行时。日常安装无需这些参数。

安装后复验：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\verify.ps1
```

停用配置：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\uninstall.ps1
```

停用会备份并移除本包管理的 MCP 与路由规则，将管理的 Skill 移入备份；保留运行时和用户所有 PPT 项目。

## 如何制作与继续改稿

deck 项目保存为 `super-adc-deck.json` + `slides/*.html` + `assets/`；原生项目保存为 `ppt-workbench-native.json` + `versions/` + `work/` + `plans/`。MCP 共 25 个工具：原有16个 deck 工具、7个 pptx_* 工具，以及 ppt_asset/ppt_placement_plan。原生稿保持原始页面尺寸，不转换为1920×1080。

check 在 Chromium 中测量全部页面，返回页码、元素路径和文字诊断；未变化页按源文件、资源、字体、浏览器及引擎指纹复用测量。export 在检查无错误后导出原生文本框、表格、形状、图片，保存新版本并更新 progress.md。错误示例包括文字重叠、超出画布、图片或字体缺失。

preview 生成本地 PNG 与联系表，工具只返回路径。首次设计、复杂页面及最终审美验收仍应按需看图，程序检查无法代替全部视觉判断。不要把“文件已导出”当作“创意和排版已经验收”。

新聊天继续旧项目：

```text
继续修改 D:\我的项目\提案\super-adc-deck.json。
先读 progress.md 和 notes 中的决定，再按本轮反馈局部修改。
```

批注、文案修改和确认过的设计决定要落到 notes，不能只放在聊天历史。若用户已经手改导出的 PPTX，以最新 PPTX 为事实源，使用 officecli 或其他原文件编辑工具；本引擎不支持无损 PPTX→HTML 反向同步。

新聊天先调用 deck_resume。通过 deck_context 记录当前工作重点、参考资料的用途、已确认项和待办；不必填满所有字段。改稿工具自动快照，直接用终端/文件编辑器修改前需主动调用 deck_snapshot。快照只覆盖清单、slides、assets、notes、progress.md、handoff.md，保留历史导出；恢复前检查变更清单，应用时校验当前内容指纹。完整历史随 .ppt-workbench 一起迁移。

稳定元素通过 data-ppt-id 定位，能在插入或移动其他元素后继续定点修改。deck_media 保存调用方实际查阅后的素材摘要和指纹，避免把旧图片结论用于新图片；它本身不查看图片，也不改变会话上下文。

## 图片上限与 OfficeCLI

此前错误表示那一次模型请求包含 103 个图像输入，而该通道最多允许 100 个。模型调用可能携带前面轮次的图片和工具图片，所以本轮没加图片也能再次失败；日志“看了几张图”并不等于实际请求图片数。这个包改变日常检查方式：测量、查尺寸、导出只返回文字，避免不断把幻灯片截图灌入模型。

它不能删除 Codex 内部已有图片历史，不能修改第三方模型网关限制，也不能承诺其他工具不会带入图片。已经卡住的聊天应保存当前文件，在新聊天依据源文件/notes/progress.md 接续。缩小图像像素或反复重试不解决“图像数量”超限。

officecli 适合读写已有 Office 文件、查询对象、做定点修改；它不是请求历史过滤器，也不等同于 SuperADC 的 Chromium 测量与导出引擎。两者可配合。`ppt-rebuild-workflow` 适合截图/纯图重建与增量模式选择，单独复制 Skill 同样不会获得宿主服务。

本包覆盖新建 deck 与原生 PPTX 精修的项目管理和检查流程。不捆绑 OfficeCLI 二进制、图片生成账号或完整重建技能；已有工具可继续使用，缺少时不能假装这些功能已安装。

## 边界与来源

支持有限 HTML/CSS 方言，详见 `skills/ppt-workbench/references/dialect.md`。不支持任意网页转换、动画、讲稿备注、原生数据绑定图表、合并单元格或 SuperADC 的 UI 圈选批注。浏览器与 PowerPoint 字体渲染仍可能存在细微差异；其他字体、Office/WPS 版本应实际验收。

`src/vendor/deck-engine.mjs` 从用户已安装的 SuperADC 0.580.0 bundle 中按依赖闭包抽取，包含本次修补；版本、来源哈希、声明位置和改动记录在 PROVENANCE.json。宿主代理、账户、模型密钥、上下文服务未打包。独立适配器负责浏览器、缓存、文件锁、MCP 与安装。升级 SuperADC 不会自动改变此包；后续升级需重新抽取、检查和验证。

开发验收：`npm ci` 后运行 `npm test`；运行时安装使用 `npm ci --omit=dev`。实际验收记录见 `验收说明.md`。

用户级技能目录及全局配置发现规则参考 [OpenAI Skills 文档](https://learn.chatgpt.com/docs/build-skills)和 [AGENTS.md 文档](https://learn.chatgpt.com/docs/agent-configuration/agents-md)。安装器和实际验收记录是本仓库行为的依据。
